# Welcome to the work of Mark Anthony Garcia 

Working on ORCA: An Interactive Chatbot (Thesis 1)

METHOD OF WORK: Not Professional

Front-End with Database System developed using language in HTML, CSS, JS, PHPmyAdmin, MYSQL, and BootStrap (iCONS, FONTS STYLE)

IDE: NOTEPAD++ XAMPP

Read this to make a webpage works properly this code shared into GITHUB (profile: MarkGarcia14/garcia.181514@ortigas-cainta.sti.edu.ph) at 2024-11-04 4:00 AM UTC+8 (Asia/Manila):






//	Not Professional Status of Execution


ANYTHING YOU SEE IS BASED ON GOOGLE CAUSE AM NOT PRO IN CODING FOR NOT USING GOOGLE XD

ANYTHING I FORGOT TO PLACE HERE CONTACT ME! JUST CALL " I MISS HER BRO " ahahah

IMG (IMAGES) USE PROPER SHORTCUT FOR THEM WHEN YOU DIDN'T KNOW WHAT ICON IT IS IT'S NOT MY PROBLEM xD
VS.CODE A FILE TO WORK ON VS CODE EXTENSIONS (FILES)


THIS FILE IS NOT UPDATED FROM WHAT I HAVE IT IS ONLY A COPYCAT (UPDATED FILES ARE STILL WORKING) SINCE I NEED TO PASS IT ON GITHUB
BECAUSE WE DON'T HAVE FILE TO PROPERLY CHECKED.

DATABASE CODES ARE CODED IN PHP IT IS AN EXAMPLE SESSION ONLY (PYTHON LANGUAGE IS THE MAIN  )



//Folder methods



When you download this make sure that each code you seen on folder is arranged, every code you seen from this code
have the name which part they're assigned so make sure to arranged them


if there was an error it is your problem not me because I checked those files before I share it



When you seen a php file use xampp but when it is html only double clicked you will see it on icons



When you see only codes text has been published not the output it is your problem not mine 





When things are not working that's what we called SKILL ISSUE xD






//Front End Design are still processing still not completed cuz why not ahahahahaaha



1) Landing page good?
2) Admin Login page working to make responsive website, it should use max-width or height but design is good?
3) Chatbot page good? Encounter problem when running it on Xampp the loading session is so slow I guess it needs internet connection if still not showing IDK because it only works without APACHE i guess
4) Conversation page still working on it still thinking if I do it on webpage or i place it on a button on Chatbot page
5) Creating User page is not connected on database of view user, so still working on that
6) Side bar is good? Still encounter problems on Xampp using Apache because the bootstrap icons are been hide I dont know what reason maybe because the security of Apache (localhost) thats why any bootstrap are not being connected
7) Rating&Feedback is good? It depends on you if you use html or php, the reason I use php instead html for this because the <form action>
8) Dashboard is still not done ahahahaha
9) Profile and search is on the FIGMA do not blame me bro ahaahahaha (not updated created by James Patacsil)
10)Anything I forgot to say just ask me (Mark Garcia Lequin)





//Front END Database are just an example don't be tilt bro



	IN DATABASE YOU SHOULD USED MY DEFAULT TO SEE THE Rating&Feedback and View User the reason is it's not connected on admin login page.html as checker of what user logged 
	that been register in SQL DATABASE

1) create an SQL database "feedback or anything you want"
2) import SQL file present in the databse folder of the project file		 (Location: database/feedback.sql)
3) Place the project file in the root directory of your server (change the root database if you're not using feedback)
4) Navigate to the root directory for submitting feedback and "/admin" for viewing feedback & ratings
5) Default username: garcia.181514@ortigas-cainta.sti.edu.ph , password: i miss her bro
6) On the Database the ID is not arrange asc and desc because I try to drop the rows in sql and try to reset the numbering but it is primary key so am still working for that
7) feedback & ratings is same code as the view user
8) The create user page.html are not connected to view user, that is different database so am still working from that
9) Chatbot response is nothing but there was an php code that will show only the profile of an user
10)Anything database included are just an idea to ensure that our backend (Avilla) will sync from what am I doing

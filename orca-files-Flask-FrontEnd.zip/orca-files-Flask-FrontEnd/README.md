# orca-files

# GIT COMMANDS

git init <br>
git add .<br>
git commit -m "message" <br>
git branch <new_branch_name> <br>
git push -u origin <new_branch_name><br>
